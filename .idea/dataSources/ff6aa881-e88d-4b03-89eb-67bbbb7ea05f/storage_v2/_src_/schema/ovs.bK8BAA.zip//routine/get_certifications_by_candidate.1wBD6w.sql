create
    definer = root@localhost procedure get_certifications_by_candidate(IN temp_candidate_id int)
begin
    SELECT c_name, description FROM certification where candidate_id = temp_candidate_id;
end;

