create
    definer = root@localhost procedure get_schools_by_candidate(IN temp_candidate_id int)
begin
    SELECT s_name, degree FROM school where candidate_id = temp_candidate_id;
end;

