create
    definer = root@localhost procedure when_will_start_and_end_the_election(IN temp_election_id int)
begin
    SELECT start_date, end_date FROM election where eid = temp_election_id;
end;

