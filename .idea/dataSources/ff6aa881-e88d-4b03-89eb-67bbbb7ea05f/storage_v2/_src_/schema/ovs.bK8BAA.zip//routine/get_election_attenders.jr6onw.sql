create
    definer = root@localhost procedure get_election_attenders(IN temp_election_id int)
begin
    SELECT candidate_id FROM election_candidate where election_id = temp_election_id;
end;

