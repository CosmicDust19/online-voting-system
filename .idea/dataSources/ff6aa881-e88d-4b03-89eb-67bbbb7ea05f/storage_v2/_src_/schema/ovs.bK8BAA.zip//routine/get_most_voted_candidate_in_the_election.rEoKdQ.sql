create
    definer = root@localhost procedure get_most_voted_candidate_in_the_election(IN temp_eid int)
begin
    Select candidate_id, name, MAX(vote_count) as winner_vote_count
    from (SELECT vote.candidate_id, CONCAT_WS(' ', f_name, IFNULL(m_name, ''), l_name) as name, COUNT(vote_id) as vote_count
          FROM vote
                   INNER JOIN user ON vote.candidate_id = user.uid
          WHERE election_id = temp_eid
          GROUP by candidate_id) as winner;
end;

