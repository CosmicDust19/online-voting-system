create
    definer = root@localhost procedure get_user_emails(IN temp_user_id int)
begin
    SELECT email from user_emails where uid = temp_user_id;
end;

