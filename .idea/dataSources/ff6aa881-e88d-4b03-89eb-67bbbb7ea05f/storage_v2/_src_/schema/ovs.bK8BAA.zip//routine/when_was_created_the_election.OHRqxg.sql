create
    definer = root@localhost procedure when_was_created_the_election(IN temp_election_id int)
begin
    SELECT creation_date FROM election where eid = temp_election_id;
end;

