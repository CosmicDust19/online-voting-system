create
    definer = root@localhost procedure get_election_votes_by_eid(IN temp_eid int)
begin
    SELECT vote.candidate_id, CONCAT_WS(' ', f_name, IFNULL(m_name, ''), l_name) as name, COUNT(vote_id) as vote_count
    FROM vote
             INNER JOIN user ON vote.candidate_id = user.uid
    WHERE election_id = temp_eid
    GROUP by candidate_id;
end;

