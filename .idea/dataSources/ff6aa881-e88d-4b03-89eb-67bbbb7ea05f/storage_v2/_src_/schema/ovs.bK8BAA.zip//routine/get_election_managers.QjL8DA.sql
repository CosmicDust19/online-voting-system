create
    definer = root@localhost procedure get_election_managers(IN temp_election_id int)
begin
    SELECT admin_id FROM election_manager where election_id = temp_election_id;
end;

