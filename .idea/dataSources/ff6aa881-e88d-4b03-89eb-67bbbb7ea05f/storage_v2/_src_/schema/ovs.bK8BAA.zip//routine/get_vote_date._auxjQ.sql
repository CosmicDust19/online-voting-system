create
    definer = root@localhost procedure get_vote_date(IN temp_voter_id int, IN temp_election_id int)
begin
    SELECT vote_date from vote WHERE voter_id = temp_voter_id AND election_id = temp_election_id;
end;

