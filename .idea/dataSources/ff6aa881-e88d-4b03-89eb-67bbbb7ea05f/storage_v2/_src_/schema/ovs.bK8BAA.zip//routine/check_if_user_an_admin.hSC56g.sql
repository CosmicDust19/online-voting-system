create
    definer = root@localhost procedure check_if_user_an_admin(IN temp_uid int)
begin
    SELECT temp_uid as admin_id, IF(EXISTS(SELECT uid FROM admin WHERE uid = temp_uid), 'true', 'false') AS exist;
end;

