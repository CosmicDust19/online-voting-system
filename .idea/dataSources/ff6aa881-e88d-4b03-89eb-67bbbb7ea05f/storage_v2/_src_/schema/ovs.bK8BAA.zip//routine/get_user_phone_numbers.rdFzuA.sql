create
    definer = root@localhost procedure get_user_phone_numbers(IN temp_user_id int)
begin
    SELECT phone_number from user_phone_numbers where uid = temp_user_id;
end;

