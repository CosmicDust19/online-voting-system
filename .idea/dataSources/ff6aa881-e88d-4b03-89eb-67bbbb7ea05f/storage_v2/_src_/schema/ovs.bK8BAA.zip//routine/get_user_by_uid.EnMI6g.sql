create
    definer = root@localhost procedure get_user_by_uid(IN temp_user_id int)
begin
    SELECT uid, CONCAT_WS(' ', f_name, IFNULL(m_name, ''), l_name) as name, address, birth_date from user where uid = temp_user_id;
end;

